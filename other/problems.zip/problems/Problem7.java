public class Problem7 {
	public static void main(String[] args) {
		char ch = "a";
	}
}
