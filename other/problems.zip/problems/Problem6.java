import java.util.ArrayList;

public class Problem6 {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<Integer>(5);
		int i = list.get(0);
	}
}
